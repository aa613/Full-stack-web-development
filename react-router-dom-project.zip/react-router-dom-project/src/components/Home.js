import React from "react";
import "./Header.css";
const Home = () => {
  return (
    <header>
      <h1>Welcome to React Router DOM Tutorials</h1>

      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum magni
        est et odit dolorem officia sed voluptatibus aperiam provident nam alias
        tempore sint assumenda, consequatur qui error eveniet magnam
        aliquid.pxex Lorem ipsum dolor, sit amet consectetur adipisicing elit.
        Harum magni est et odit dolorem officia sed voluptatibus aperiam
        provident nam alias tempore sint assumenda, consequatur qui error
        eveniet magnam aliquid.
      </p>
    </header>
  );
};

export default Home;
