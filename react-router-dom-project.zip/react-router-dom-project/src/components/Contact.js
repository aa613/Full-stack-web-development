import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>Contact</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, ratione!
        Pariatur necessitatibus fuga earum cupiditate, officiis repellendus
        voluptate expedita laudantium quibusdam tempore, iusto laboriosam minima
        velit possimus! Dolore, reprehenderit atque?
      </p>
    </div>
  );
};

export default Contact;
