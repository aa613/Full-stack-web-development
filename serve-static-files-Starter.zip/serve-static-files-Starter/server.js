const express = require("express");
const app = express();

//home
app.get("/", (req, res) => {
  res.send("Welcome Home");
});

//about page
app.get("/about", (req, res) => {
  res.send("About Us");
});

//add post
app.post("/addPost", (req, res) => {
  res.send("Create Post");
});

//get post form
app.get("/get-form", (req, res) => {
  //display html page
  res.send("Get post form");
});

app.listen(3000, () => {
  console.log("Server started on port 3000");
});
