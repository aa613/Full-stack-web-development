//select element
const mLeave = document.querySelector(".mLeave");
const mEnter = document.querySelector(".mEnter");
const mOver = document.querySelector(".mOver");
const mOut = document.querySelector(".mOut");
const mMove = document.querySelector(".mMove");
const mClick = document.querySelector(".mClick");
const mDblClick = document.querySelector(".mDblClick");
const mWheel = document.querySelector(".mWheel");
const mContext = document.querySelector(".mContext");
const mUp = document.querySelector(".mUp");
const msgEl = document.querySelector(".msg");
