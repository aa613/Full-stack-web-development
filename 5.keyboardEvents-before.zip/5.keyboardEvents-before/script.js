//select h1
const h1 = document.querySelector("h1");
